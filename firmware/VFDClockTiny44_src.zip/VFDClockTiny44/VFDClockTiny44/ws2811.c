#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <avr/interrupt.h>
#include <string.h>
#include "ws2811.h"

// Backlight colors COLORS[color_index][led_index][rgb]
uint8_t COLORS[10][4][3] = {
	{{0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}},
	{{0,0,30}, {0,0,30}, {0,0,30}, {0,0,30}},
	{{0,10,20}, {0,10,20}, {0,10,20}, {0,10,20}},
	{{0,20,10}, {0,20,10}, {0,20,10}, {0,20,10}},
	{{20,20,0}, {20,20,0}, {20,20,0}, {20,20,0}},
	{{30,3,0}, {30,3,0}, {30,3,0}, {30,3,0}},
	{{30,0,0}, {30,0,0}, {30,0,0}, {30,0,0}},
	{{30,0,15}, {30,0,15}, {30,0,15}, {30,0,15}},
	{{8,0,30}, {8,0,30}, {8,0,30}, {8,0,30}},
	{{0,20,20}, {30,0,15}, {30,3,0}, {30,0,0}},
};

uint8_t led_color[4][3] = {{0,0,0}, {0,0,0}, {0,0,0}, {0,0,0}};
uint8_t color_i_old = 0;

void set_0(void) {
	set_led_pin();
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	reset_led_pin();
}

void set_1(void) {
	set_led_pin();
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	asm("NOP");
	reset_led_pin();
}

uint8_t ws2811_init(void) {
	LED_DDR |= 1<<LED_PIN;
	return sizeof(COLORS) / sizeof(COLORS[0]);
}

void set_led_color(void) {
	cli();
	for(uint8_t i=0; i<4; i++) {
		for(uint8_t j=0; j<3; j++) {
			if((led_color[i][j]) >> 7 & 1) set_1(); else set_0();
			if((led_color[i][j]) >> 6 & 1) set_1(); else set_0();
			if((led_color[i][j]) >> 5 & 1) set_1(); else set_0();
			if((led_color[i][j]) >> 4 & 1) set_1(); else set_0();
			if((led_color[i][j]) >> 3 & 1) set_1(); else set_0();
			if((led_color[i][j]) >> 2 & 1) set_1(); else set_0();
			if((led_color[i][j]) >> 1 & 1) set_1(); else set_0();
			if((led_color[i][j]) >> 0 & 1) set_1(); else set_0();
		}
	}
	sei();
}

void color_copy(int8_t i, uint8_t j) {
	memcpy(led_color[i], COLORS[j][i], 3);
}

void set_backlight(uint8_t color_i) {
	if (color_i > color_i_old) {
		for (int8_t i=0; i<4; i++) {
			color_copy(i, color_i_old);
		}
		for (int8_t i=0; i<4; i++) {
			color_copy(i, color_i);
			set_led_color();
			_delay_ms(50);
		}
	} else {
		for (int8_t i=3; i>-1; i--) {
			color_copy(i, color_i_old);
		}
		for (int8_t i=3; i>-1; i--) {
			color_copy(i, color_i);
			set_led_color();
			_delay_ms(50);
		}
	}
	color_i_old = color_i;	
}