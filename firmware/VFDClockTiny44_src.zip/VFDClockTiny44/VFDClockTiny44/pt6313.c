#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include "pt6313.h"
#include <string.h>
#include <stdbool.h>

#define stb_set() PT6313_PORT |= 1<<PT6313_STB
#define stb_res()  PT6313_PORT &= ~(1<<PT6313_STB)

// _ E D C B A G F

uint8_t numbers[23] = {0x7D, 0x18, 0x6E, 0x3E, 0x1B, 0x37, 0x77, 0x1C, 0x7F, 0x3F, 0x5B, 0x42, 0x54, 0x52, 0x7A, 0x73, 0x61, 0x67, 0x02, 0x63, 0x00, 0x0F, 0x60};
uint8_t CMD_1 = 0x01;
uint8_t CMD_2 = 0x44;
uint8_t CMD_3[5] = {0xC0, 0xC2, 0xC4, 0xC6, 0xC8};
uint8_t CMD_4 = 0x8F;
uint8_t display_data_old[5] = {0, 0, 0, 0, 0};

void pt6313_init(void) {
	PT6313_DDR |= (1<<PT6313_CLK) | (1<<PT6313_DIN) | (1<<PT6313_STB);
	PT6313_PORT |= 1<<PT6313_STB;
}

void display_brightness(uint8_t value) {
	CMD_4 = value;
}

void shift_out(uint8_t value) {
	PT6313_PORT &= ~(1<<PT6313_DIN);
	_delay_us(5);
	for (uint8_t i = 0; i < 8; i++) {
		if(value & (1<<i)) PT6313_PORT |= 1<<PT6313_DIN; else PT6313_PORT &= ~(1<<PT6313_DIN);
		_delay_us(5);
		PT6313_PORT |= 1<<PT6313_CLK;
		_delay_us(3);
		PT6313_PORT &= ~(1<<PT6313_CLK);
	}
	PT6313_PORT &= ~(1<<PT6313_DIN);
	_delay_us(5);
}

void write_to_pt6313(uint8_t digit, uint8_t digit_value) {
	stb_res();
	shift_out(CMD_2);
	stb_set();
	_delay_us(10);
	stb_res();
	shift_out(digit);
	shift_out(digit_value);
	stb_set();
	_delay_us(10);
	stb_res();
	shift_out(CMD_1);
	stb_set();
	_delay_us(10);
	stb_res();
	shift_out(CMD_4);
	stb_set();
	_delay_us(10);
}

void display(uint8_t dig_1_val, uint8_t dig_2_val, uint8_t dig_3_val, uint8_t dig_4_val, uint8_t sep_dot, bool effect) {
	uint8_t display_data[5] = {
		numbers[dig_1_val],
		numbers[dig_2_val],
		numbers[dig_3_val],
		numbers[dig_4_val],
		numbers[sep_dot]
	};
	write_to_pt6313(CMD_3[4], display_data[4]); // separator
	uint8_t display_data_eff[5];
	memcpy(display_data_eff, display_data_old, 5);
	// effect out
	for(uint8_t j=0; j<5; j++) {
		for (uint8_t i=0; i<4; i++) {
			if(display_data[i] != display_data_old[i]) {
				switch(j){
					case 0: display_data_eff[i] &= ~(1<<2); break;
					case 1: display_data_eff[i] &= ~((1<<0)|(1<<3)); break;
					case 2: display_data_eff[i] &= ~(1<<1); break;
					case 3: display_data_eff[i] &= ~((1<<4)|(1<<6)); break;
					case 4: display_data_eff[i] &= ~(1<<5); break;
				}			
				write_to_pt6313(CMD_3[i], display_data_eff[i]);
			}
		}
		if(effect) _delay_ms(50);
	}
	// effect in
	for(uint8_t j=0; j<5; j++) {
		for (uint8_t i=0; i<4; i++) {
			if(display_data[i] != display_data_old[i]) {
				switch(j){
					case 0: if(display_data[i] & (1<<2)) display_data_eff[i] |= 1<<2; break;
					case 1:
							if(display_data[i] & (1<<0)) display_data_eff[i] |= 1<<0;
							if(display_data[i] & (1<<3)) display_data_eff[i] |= 1<<3;
						break;
					case 2: if(display_data[i] & (1<<1)) display_data_eff[i] |= 1<<1; break;
					case 3:
							if(display_data[i] & (1<<4)) display_data_eff[i] |= 1<<4;
							if(display_data[i] & (1<<6)) display_data_eff[i] |= 1<<6;
						break;
					case 4: if(display_data[i] & (1<<5)) display_data_eff[i] |= 1<<5; break;
				}				
				write_to_pt6313(CMD_3[i], display_data_eff[i]);
			}
		}
		if(effect) _delay_ms(50);
	}
	memcpy(display_data_old, display_data, 5);
}