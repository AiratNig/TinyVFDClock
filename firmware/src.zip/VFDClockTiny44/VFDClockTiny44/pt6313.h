#include <stdbool.h>

#ifndef PT6313_H_
#define PT6313_H_

#define PT6313_DDR	DDRA
#define PT6313_PORT	PORTA
#define PT6313_DIN	PORTA1
#define PT6313_CLK	PORTA0
#define PT6313_STB	PORTA7

#define H 10
#define R 11
#define M 12
#define N 13
#define S 5
#define D 14
#define B 15
#define L 16
#define E 17
#define DASH 18
#define T 19
#define OFF 20
#define DEG 21
#define I 22

#define SEP_ON 0
#define SEP_OFF 1

#define BRIGHT_MAX 0x8F
#define BRIGHT_MIN 0x88

void pt6313_init(void);
void display_brightness(uint8_t value);
void display(uint8_t dig_1_val, uint8_t dig_2_val, uint8_t dig_3_val, uint8_t dig_4_val, uint8_t sep_dot, bool effect);

#endif