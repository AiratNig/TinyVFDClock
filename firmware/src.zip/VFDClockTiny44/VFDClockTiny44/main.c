#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdbool.h>
#include <avr/eeprom.h>
#include "i2c.h"
#include "ws2811.h"
#include "pt6313.h"

#define DS1339 0x20
#define DS3231 0x40

uint16_t button_adc = 0;
uint16_t light_adc = 0;
uint8_t HR;
uint8_t MN;
uint8_t SC;
uint8_t menu = 0;
uint8_t BL;
uint8_t LS;
uint8_t ST;
bool sep_state = false;
bool rtc_int = false;
uint8_t leds_n;

void adc_init(void) {
	ADCSRA |= 1<< ADEN;
	ADCSRA |= (1<<ADPS2) | (1<<ADPS1);
}

void pcint_init(void) {
	GIMSK |= (1<<PCIE0);
	PCMSK0 |= (1<<PCINT6);
}

uint16_t get_adc_val(uint8_t adc_channel) {
	adc_channel &= 0b00000111;
	ADMUX = (ADMUX & 0xF8) | adc_channel;
	ADCSRA |= (1<<ADSC);
	while(ADCSRA & (1<<ADSC));
	return (ADC);
}

uint8_t dec_2_bcd(uint8_t val) {
	return ((val / 10 * 16) + (val % 10));
}

uint8_t bcd_2_dec(uint8_t val) {
	return ((val / 16 * 10) + (val % 16));
}

void rtc_init(uint8_t rtc_type) {
	i2c_start();
	i2c_send_byte(0xD0);
	i2c_send_byte(0x0E);
	i2c_send_byte(rtc_type);
	i2c_stop();
}

void set_rtc(uint8_t address, uint8_t data) {
	i2c_start();
	i2c_send_byte(0xD0);
	i2c_send_byte(address);
	i2c_send_byte(dec_2_bcd(data));
	i2c_stop();
}

void read_rtc(void) {
	i2c_start();
	i2c_send_byte(0xD0);
	i2c_send_byte(0);
	i2c_restart();
	i2c_send_byte(0xD1);
	SC = bcd_2_dec(i2c_read_byte(ACK));
	MN = bcd_2_dec(i2c_read_byte(ACK));
	HR = bcd_2_dec(i2c_read_byte(NACK));
	i2c_stop();
}

uint8_t get_temperature(void) {
	i2c_start();
	i2c_send_byte(0x9E);
	i2c_send_byte(0);
	i2c_restart();
	i2c_send_byte(0x9F);
	uint8_t temp_msb = i2c_read_byte(NACK);
	i2c_stop();
	return (temp_msb);
}

ISR(PCINT0_vect) {
	if(!(PINA & (1<<PINA6))) rtc_int = true;
}

int main(void) {
	_delay_ms(500);
	adc_init();
	pcint_init();
	i2c_init();
	leds_n = ws2811_init();
	pt6313_init();
	rtc_init(DS3231);
	BL = eeprom_read_byte((uint8_t*)0);
	LS = eeprom_read_byte((uint8_t*)1);
	ST = eeprom_read_byte((uint8_t*)2);
	if (BL > (leds_n-1)) BL = 0;
	display_brightness(BRIGHT_MAX);
	sei();
    while (1) {
		// get buttons state
		button_adc = get_adc_val(3);
		if(button_adc > 1000 && menu == 0 && rtc_int == true) {
			read_rtc();
			light_adc = get_adc_val(2);
			// backlight control
			if (LS == 1 && light_adc < 50) {
				display_brightness(BRIGHT_MIN);
				set_backlight(0);
			} else {
				display_brightness(BRIGHT_MAX);
				set_backlight(BL);
			}
			sep_state = !sep_state;
			if(ST == 1) {
				if(SC >= 30 && SC < 35) {
					// Show temperature
					if(SC >= 30 && SC < 35) display(OFF, get_temperature()/10, get_temperature()%10, DEG, SEP_OFF, true);
				} else {
					display(HR/10, HR%10, MN/10, MN%10, sep_state, true);
				}
			} else {
				display(HR/10, HR%10, MN/10, MN%10, sep_state, true);
			}
			rtc_int = false;
		}
		// Menu button
		if (button_adc < 10) {
			_delay_ms(150);
			if((menu++) >= 7) menu = 1;
			switch(menu) {
				case 1: display(H, R, HR/10, HR%10, SEP_OFF, false); break;
				case 2: display(M, N, MN/10, MN%10, SEP_OFF, false); break;
				case 3: display(S, D, SC/10, SC%10, SEP_OFF, false); break;
				case 4: display(B, L, BL/10, BL%10, SEP_OFF, false); break;
				case 5: display(L, S, LS/10, LS%10, SEP_OFF, false); break;
				case 6: display(S, T, ST/10, ST%10, SEP_OFF, false); break;
				case 7: display(E, S, DASH, DASH, SEP_OFF, false); break;
			}
		}
		// Up button
		if(button_adc > 500 && button_adc < 550) {
			_delay_ms(150);
			switch(menu) {
				case 1:
					if((HR++) >= 23) HR = 23;
					display(H, R, HR/10, HR%10, SEP_ON, false);
					set_rtc(2, HR);
					break;
				case 2:
					if((MN++) >= 59) MN = 59;
					display(M, N, MN/10, MN%10, SEP_ON, false);
					set_rtc(1, MN);
					break;
				case 3:
					if((SC++) >= 59) SC = 59;
					display(S, D, SC/10, SC%10, SEP_ON, false);
					set_rtc(0, SC);
					break;
				case 4:
					if((BL++) >= (leds_n-1)) BL = (leds_n-1);
					display(B, L, BL/10, BL%10, SEP_ON, false);
					set_backlight(BL);
					cli();
					eeprom_write_byte((uint8_t*)0, BL);
					sei();
					break;
				case 5:
					LS = !LS;
					display(L, S, LS/10, LS%10, SEP_ON, false);
					cli();
					eeprom_write_byte((uint8_t*)1, LS);
					sei();
					break;
				case 6:
					ST = !ST;
					display(S, T, ST/10, ST%10, SEP_ON, false);
					cli();
					eeprom_write_byte((uint8_t*)2, ST);
					sei();
					break;
				case 7:
					menu = 0;
					break;
			}
		}
		// Down button
		if(button_adc > 650 && button_adc < 700) {
			_delay_ms(150);
			switch(menu) {
				case 1:
					if((HR--) == 0) HR = 0;
					display(H, R, HR/10, HR%10, SEP_ON, false);
					set_rtc(2, HR);
					break;
				case 2:
					if((MN--) == 0) MN = 0;
					display(M, N, MN/10, MN%10, SEP_ON, false);
					set_rtc(1, MN);
					break;
				case 3:
					if((SC--) == 0) SC = 0;
					display(S, D, SC/10, SC%10, SEP_ON, false);
					set_rtc(0, SC);
					break;
				case 4:
					if((BL--) == 0) BL = 0;
					display(B, L, BL/10, BL%10, SEP_ON, false);
					set_backlight(BL);
					cli();
					eeprom_write_byte((uint8_t*)0, BL);
					sei();
					break;
				case 5:
					LS = !LS;
					display(L, S, LS/10, LS%10, SEP_ON, false);
					cli();
					eeprom_write_byte((uint8_t*)1, LS);
					sei();
					break;
				case 6:
					ST = !ST;
					display(S, T, ST/10, ST%10, SEP_ON, false);
					cli();
					eeprom_write_byte((uint8_t*)2, ST);
					sei();
					break;
				case 7:
					menu = 0;
					break;
			}
		}
		//_delay_ms(50);
    }
}