#ifndef WS2811_H_
#define WS2811_H_

#define		LED_DDR		DDRB
#define		LED_PORT	PORTB
#define		LED_PIN		PORTB2

#define		set_led_pin()		LED_PORT |= 1<<LED_PIN
#define		reset_led_pin()		LED_PORT &= ~(1<<LED_PIN)

uint8_t ws2811_init(void);
void set_backlight(uint8_t color_i);

#endif